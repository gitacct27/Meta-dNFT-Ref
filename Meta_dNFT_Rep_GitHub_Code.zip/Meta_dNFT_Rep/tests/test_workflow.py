from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from meta_dnft_rep.credentials import CredentialAuthority
from meta_dnft_rep.marketplace import Ledger, Marketplace
from meta_dnft_rep.model import AuditError, Event, PolicyError
from meta_dnft_rep.reputation import ReputationGraph


class WorkflowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tails = TemporaryDirectory()
        cls.addClassCleanup(cls.tails.cleanup)
        cls.authority = CredentialAuthority(Path(cls.tails.name), capacity=8)
        cls.alice = cls.authority.issue("alice")
        cls.bob = cls.authority.issue("bob")
        cls.revocable = cls.authority.issue("revocable")
        cls.graph = ReputationGraph([["alice", "trusted", 1]], ["trusted"], steps=4, restart=0)

    def setUp(self):
        directory = TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        self.ledger = Ledger(Path(directory.name) / "db.sqlite3", create=True)
        self.addCleanup(self.ledger.close)
        self.market = Marketplace(self.ledger, self.authority, self.graph)
        self.listed = Event("first", "Listed", "token", "alice", 10, 0, 1, "Example")
        self.changed = Event("second", "PriceChanged", "token", "alice", 11, 1, 2)

    def submit(self, event, holder):
        challenge = self.market.challenge(event)
        return self.market.submit(event, challenge.nonce, self.authority.present(holder, challenge))

    def test_listing_price_and_idempotent_retry(self):
        first = self.submit(self.listed, self.alice)
        self.assertEqual(first, self.submit(self.listed, self.alice))
        second = self.submit(self.changed, self.alice)
        self.assertEqual(first.commitment, second.previous)
        self.assertEqual(self.ledger.states()["token"]["version"], 2)
        self.assertEqual(self.ledger.states()["token"]["price_wei"], 11)
        self.assertEqual(len(self.ledger.audit()), 2)

    def test_policy_rejects_wrong_wallet_owner_and_version(self):
        with self.assertRaises(PolicyError):
            self.submit(self.listed, self.bob)
        self.submit(self.listed, self.alice)
        with self.assertRaises(PolicyError):
            self.submit(replace(self.changed, wallet="bob"), self.bob)
        with self.assertRaises(PolicyError):
            self.submit(replace(self.changed, expected_version=0), self.alice)
        self.assertEqual(len(self.ledger.audit()), 1)

    def test_challenge_is_payload_bound_and_single_use(self):
        challenge = self.market.challenge(self.listed)
        proof = self.authority.present(self.alice, challenge)
        with self.assertRaises(PolicyError):
            self.market.submit(replace(self.listed, price_wei=12), challenge.nonce, proof)
        with self.assertRaises(PolicyError):
            self.market.submit(self.listed, challenge.nonce, proof)
        self.assertEqual(self.ledger.audit(), [])

    def test_revoked_credential_is_rejected_by_native_verifier(self):
        event = replace(self.listed, wallet="revocable")
        self.authority.revoke("revocable")
        challenge = self.market.challenge(event)
        proof = self.authority.present(self.revocable, challenge)
        with self.assertRaises(PolicyError):
            self.market.submit(event, challenge.nonce, proof)
        self.submit(self.listed, self.alice)
        self.assertEqual(len(self.ledger.audit()), 1)

    def test_audit_detects_changed_private_snapshot(self):
        self.submit(self.listed, self.alice)
        self.ledger.db.execute("UPDATE states SET payload = '{}' WHERE token_id = 'token'")
        with self.assertRaises(AuditError):
            self.ledger.audit()

    def test_graph_signals_have_known_limits(self):
        self.assertEqual(self.graph.hitting_time("alice"), 1)
        self.assertEqual(self.graph.hitting_time("unknown"), 4)
        self.assertEqual(self.graph.walk_trust("alice"), 1)
        self.assertEqual(self.graph.walk_trust("unknown"), 0)


if __name__ == "__main__":
    unittest.main()
