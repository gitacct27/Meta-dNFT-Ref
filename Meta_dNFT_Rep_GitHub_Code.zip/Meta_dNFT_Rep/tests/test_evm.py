from importlib.util import find_spec
import unittest

from meta_dnft_rep.model import AuditError, GENESIS


@unittest.skipUnless(find_spec("eth_tester") and find_spec("eth"), "Install requirements-evm.txt.")
class AnchorTest(unittest.TestCase):
    def test_real_local_contract_tracks_committed_chain(self):
        from meta_dnft_rep.evm import anchor_local
        records = [
            {"sequence": 1, "previous": GENESIS, "commitment": "a" * 64},
            {"sequence": 2, "previous": "a" * 64, "commitment": "b" * 64},
        ]
        receipt = anchor_local(records)
        self.assertEqual(receipt["count"], 2)
        self.assertEqual(receipt["head"], "b" * 64)
        self.assertTrue(all(tx["gas_used"] > 0 for tx in receipt["receipts"]))

    def test_input_chain_rejects_wrong_predecessor(self):
        from meta_dnft_rep.evm import anchor_local
        with self.assertRaises(AuditError):
            anchor_local([{"sequence": 1, "previous": "a" * 64, "commitment": "b" * 64}])
