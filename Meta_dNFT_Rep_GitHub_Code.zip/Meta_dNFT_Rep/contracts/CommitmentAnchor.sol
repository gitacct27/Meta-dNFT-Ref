// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.30;

/// @notice Anchors a sequence of opaque off-chain commitments.
contract CommitmentAnchor {
    address public immutable writer;
    bytes32 public head;
    uint256 public count;
    mapping(bytes32 => bool) private anchored;

    error UnauthorizedWriter();
    error WrongPredecessor();
    error InvalidCommitment();

    event Anchored(uint256 indexed sequence, bytes32 indexed commitment, bytes32 previous);

    constructor() {
        writer = msg.sender;
    }

    function anchor(bytes32 previous, bytes32 commitment) external {
        if (msg.sender != writer) revert UnauthorizedWriter();
        if (previous != head) revert WrongPredecessor();
        if (commitment == bytes32(0) || anchored[commitment]) revert InvalidCommitment();

        anchored[commitment] = true;
        head = commitment;
        count += 1;
        emit Anchored(count, commitment, previous);
    }
}
