const { createHash } = require("node:crypto");
const { readFileSync, writeFileSync } = require("node:fs");
const path = require("node:path");
const solc = require("solc");

const name = "CommitmentAnchor.sol";
const source = readFileSync(path.join(__dirname, name), "utf8").replace(/\r\n/g, "\n");
const input = {
  language: "Solidity",
  sources: { [name]: { content: source } },
  settings: {
    evmVersion: "paris",
    optimizer: { enabled: true, runs: 200 },
    metadata: { bytecodeHash: "none" },
    outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
  },
};
const output = JSON.parse(solc.compile(JSON.stringify(input)));
const failures = (output.errors ?? []).filter((entry) => entry.severity === "error");
if (failures.length) {
  throw new Error(failures.map((entry) => entry.formattedMessage).join("\n"));
}
const contract = output.contracts[name].CommitmentAnchor;
const artifact = {
  compiler: solc.version(),
  source_sha256: createHash("sha256").update(source, "utf8").digest("hex"),
  abi: contract.abi,
  bytecode: "0x" + contract.evm.bytecode.object,
};
writeFileSync(path.join(__dirname, "CommitmentAnchor.json"), JSON.stringify(artifact, null, 2) + "\n");
