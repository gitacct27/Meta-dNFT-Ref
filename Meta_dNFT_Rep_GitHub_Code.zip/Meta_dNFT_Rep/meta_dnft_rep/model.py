"""Marketplace events and canonical commitment serialization."""

from dataclasses import asdict, dataclass
from hashlib import sha256
import json
import re

GENESIS = "0" * 64


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def digest(value):
    return sha256(canonical(value).encode("utf-8")).hexdigest()


class PolicyError(ValueError):
    """A marketplace request violated the event or authorization policy."""


class AuditError(ValueError):
    """Stored evidence and its commitments do not agree."""


@dataclass(frozen=True, slots=True)
class Event:
    event_id: str
    kind: str
    token_id: str
    wallet: str
    price_wei: int
    expected_version: int
    timestamp: int
    name: str | None = None

    def __post_init__(self):
        for value in (self.event_id, self.token_id, self.wallet):
            if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
                raise PolicyError("Event IDs, token IDs and wallet aliases must be 1–80 ASCII identifier characters.")
        if self.kind not in {"Listed", "PriceChanged"}:
            raise PolicyError("Event kind must be Listed or PriceChanged.")
        for value, label in ((self.price_wei, "price_wei"), (self.expected_version, "expected_version"),
                             (self.timestamp, "timestamp")):
            if type(value) is not int or value < 0:
                raise PolicyError(f"{label} must be a nonnegative integer.")
        if self.timestamp >= 2**63:
            raise PolicyError("timestamp must fit a signed 64-bit Unix timestamp.")
        if not 0 < self.price_wei < 2**256:
            raise PolicyError("price_wei must be positive and below 2^256.")
        if self.kind == "Listed":
            if not isinstance(self.name, str) or not self.name.strip() or len(self.name) > 120:
                raise PolicyError("A listing requires a nonempty name of at most 120 characters.")
        elif self.name is not None:
            raise PolicyError("PriceChanged accepts only a price update.")

    @property
    def payload(self):
        return asdict(self)

    @property
    def fingerprint(self):
        return digest(self.payload)


@dataclass(frozen=True, slots=True)
class Receipt:
    sequence: int
    previous: str
    commitment: str

    @property
    def public_record(self):
        return asdict(self)
