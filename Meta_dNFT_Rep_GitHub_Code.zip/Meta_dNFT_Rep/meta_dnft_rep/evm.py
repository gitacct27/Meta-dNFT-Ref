"""Publish an audit export to the bundled contract on a local, disposable EVM."""

from hashlib import sha256
import json
from pathlib import Path
import re

from eth_abi import encode, decode
from eth_tester import EthereumTester, PyEVMBackend
from eth_utils import keccak

from .model import AuditError, GENESIS

CONTRACTS = Path(__file__).resolve().parents[1] / "contracts"


def selector(signature):
    return keccak(text=signature)[:4]


def contract_artifact():
    artifact = json.loads((CONTRACTS / "CommitmentAnchor.json").read_text(encoding="utf-8"))
    source = (CONTRACTS / "CommitmentAnchor.sol").read_text(encoding="utf-8")
    if sha256(source.encode()).hexdigest() != artifact["source_sha256"]:
        raise ValueError("Contract source changed. Rebuild the Solidity artifact.")
    return artifact


def anchor_local(records):
    previous, seen = GENESIS, set()
    for sequence, record in enumerate(records, 1):
        value = record.get("commitment", "")
        if (record.get("sequence") != sequence or record.get("previous") != previous
                or not isinstance(value, str) or re.fullmatch("[0-9a-f]{64}", value) is None
                or value == GENESIS or value in seen):
            raise AuditError(f"Invalid public commitment chain at sequence {sequence}.")
        seen.add(value)
        previous = value

    artifact = contract_artifact()
    evm = EthereumTester(backend=PyEVMBackend())
    sender = evm.get_accounts()[0]
    deployment_hash = evm.send_transaction({"from": sender, "gas": 2_000_000, "data": artifact["bytecode"]})
    deployment = evm.get_transaction_receipt(deployment_hash)
    if deployment["status"] != 1:
        raise RuntimeError("Local contract deployment failed.")
    address = deployment["contract_address"]
    receipts = []
    for record in records:
        arguments = encode(["bytes32", "bytes32"], [
            bytes.fromhex(record["previous"]), bytes.fromhex(record["commitment"]),
        ])
        data = "0x" + (selector("anchor(bytes32,bytes32)") + arguments).hex()
        transaction_hash = evm.send_transaction({"from": sender, "to": address, "gas": 300_000, "data": data})
        receipt = evm.get_transaction_receipt(transaction_hash)
        if receipt["status"] != 1:
            raise AuditError(f"Local anchor transaction failed at sequence {record['sequence']}.")
        receipts.append({
            "sequence": record["sequence"],
            "transaction_hash": transaction_hash,
            "gas_used": receipt["gas_used"],
            "block_number": receipt["block_number"],
        })

    def read(signature, field):
        value = evm.call({"from": sender, "to": address, "data": "0x" + selector(signature).hex()})
        return decode([field], bytes.fromhex(value[2:]))[0]

    head, count = read("head()", "bytes32").hex(), read("count()", "uint256")
    if head != previous or count != len(records):
        raise AuditError("Local contract state differs from the public commitment chain.")
    return {
        "backend": "eth-tester/PyEVMBackend (local and ephemeral)",
        "compiler": artifact["compiler"],
        "contract_address": address,
        "deployment_gas_used": deployment["gas_used"],
        "count": count,
        "head": head,
        "receipts": receipts,
    }
