"""Local AnonCreds issuance, selective disclosure and accumulator revocation."""

from dataclasses import dataclass
from pathlib import Path
import secrets
import time

from anoncreds import (
    AnoncredsError, Credential, CredentialDefinition, CredentialOffer,
    CredentialRequest, CredentialRevocationConfig, CredentialRevocationState,
    PresentCredentials, Presentation, PresentationRequest,
    RevocationRegistryDefinition, RevocationStatusList, Schema,
    create_link_secret, encode_credential_attributes, generate_nonce,
)

from .model import PolicyError

ISSUER = "did:example:metadnftrep"
SCHEMA_ID = ISSUER + "/anoncreds/v0/SCHEMA/member/1.0"
DEFINITION_ID = ISSUER + "/anoncreds/v0/CLAIM_DEF/member/default"
REGISTRY_ID = ISSUER + "/anoncreds/v0/REV_REG_DEF/member/default"
MEMBER = "member"


@dataclass(frozen=True, slots=True, repr=False)
class Holder:
    credential: Credential
    link_secret: str
    revocation_index: int


@dataclass(frozen=True, slots=True)
class Challenge:
    nonce: str
    event_digest: str
    request: PresentationRequest
    timestamp: int
    expires_at: float


class CredentialAuthority:
    def __init__(self, tails_dir: Path, capacity=32):
        tails_dir.mkdir(parents=True, exist_ok=True)
        self.capacity = capacity
        self.indices = {}
        self.revoked = set()
        self.timestamp = int(time.time())
        self.schema = Schema.create("member", "1.0", ISSUER, ["wallet_id", "role", "private_profile"])
        self.definition, self._private, self._correctness = CredentialDefinition.create(
            SCHEMA_ID, self.schema, ISSUER, "default", "CL", support_revocation=True,
        )
        self.registry, self._registry_private = RevocationRegistryDefinition.create(
            DEFINITION_ID, self.definition, ISSUER, "default", "CL_ACCUM", capacity,
            tails_dir_path=str(tails_dir.resolve()),
        )
        self.status = RevocationStatusList.create(
            self.definition, REGISTRY_ID, self.registry, self._registry_private,
            ISSUER, True, self.timestamp,
        )

    def issue(self, wallet, role="seller"):
        index = len(self.indices) + 1
        if wallet in self.indices or index >= self.capacity or role not in {"seller", "viewer"}:
            raise PolicyError("Duplicate enrollment, invalid role or full local credential registry.")
        offer = CredentialOffer.create(SCHEMA_ID, DEFINITION_ID, self._correctness)
        secret = create_link_secret()
        request, metadata = CredentialRequest.create(
            secrets.token_hex(24), None, self.definition, secret, "marketplace", offer,
        )
        credential = Credential.create(
            self.definition, self._private, offer, request,
            {"wallet_id": wallet, "role": role, "private_profile": secrets.token_hex(16)},
            None, CredentialRevocationConfig(self.registry, self._registry_private, self.status, index),
        ).process(metadata, secret, self.definition, self.registry)
        self.indices[wallet] = index
        return Holder(credential, secret, index)

    def revoke(self, wallet):
        index = self.indices.get(wallet)
        if index is None or wallet in self.revoked:
            raise PolicyError("Wallet has no active credential to revoke.")
        next_timestamp = self.timestamp + 1
        self.status = self.status.update(
            self.definition, self.registry, self._registry_private, None, [index], next_timestamp,
        )
        self.timestamp = next_timestamp
        self.revoked.add(wallet)

    def challenge(self, event):
        nonce = generate_nonce()
        request = PresentationRequest.load({
            "nonce": nonce,
            "name": "marketplace-event",
            "version": "1.0",
            "requested_attributes": {
                MEMBER: {"names": ["wallet_id", "role"], "restrictions": [{"cred_def_id": DEFINITION_ID}]},
            },
            "requested_predicates": {},
            "non_revoked": {"from": self.timestamp, "to": self.timestamp},
        })
        return Challenge(nonce, event.fingerprint, request, self.timestamp, time.monotonic() + 120)

    def present(self, holder, challenge):
        if challenge.timestamp != self.timestamp:
            raise PolicyError("Obtain a fresh challenge after the revocation registry changes.")
        try:
            witness = CredentialRevocationState.create(
                self.registry, self.status, holder.revocation_index, self.registry.tails_location,
            )
            attributes = PresentCredentials()
            attributes.add_attributes(
                holder.credential, MEMBER, reveal=True, timestamp=self.timestamp, rev_state=witness,
            )
            return Presentation.create(
                challenge.request, attributes, {}, holder.link_secret,
                {SCHEMA_ID: self.schema}, {DEFINITION_ID: self.definition},
            ).to_json()
        except AnoncredsError as exc:
            raise PolicyError("Could not create a presentation for the current registry.") from exc

    def verify(self, event, challenge, proof):
        if (challenge.event_digest != event.fingerprint or challenge.timestamp != self.timestamp
                or time.monotonic() > challenge.expires_at):
            raise PolicyError("Presentation challenge is expired, stale or bound to another event.")
        try:
            presentation = Presentation.load(proof)
            valid = presentation.verify(
                challenge.request, {SCHEMA_ID: self.schema}, {DEFINITION_ID: self.definition},
                {REGISTRY_ID: self.registry}, [self.status],
            )
            group = presentation.to_dict()["requested_proof"]["revealed_attr_groups"][MEMBER]["values"]
            disclosed = {key: value["raw"] for key, value in group.items()}
            encodings = {key: value["encoded"] for key, value in group.items()}
        except (AnoncredsError, KeyError, TypeError, ValueError) as exc:
            raise PolicyError("AnonCreds presentation verification failed.") from exc
        if (not valid or disclosed != {"wallet_id": event.wallet, "role": "seller"}
                or encodings != encode_credential_attributes(disclosed)):
            raise PolicyError("Presentation must prove current seller authorization for the event wallet.")
