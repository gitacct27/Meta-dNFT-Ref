"""CLI for the local Meta-dNFT-Rep workflow."""

import argparse
from contextlib import closing
import csv
import json
import platform
from math import floor
from pathlib import Path
import random
import sqlite3
import sys
import tempfile
import time

from .credentials import CredentialAuthority
from .marketplace import Ledger, Marketplace
from .model import Event, GENESIS, canonical
from .reputation import ReputationGraph

EXAMPLES = Path(__file__).resolve().parents[1] / "examples"


def load_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        for line, text in enumerate(stream, 1):
            if not text.strip():
                continue
            try:
                yield json.loads(text)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path.name}, line {line}: {exc.msg}") from exc


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def synthetic_events(count, seed):
    rng = random.Random(seed)
    for index in range(count):
        wallet = "wallet-alice" if index % 2 == 0 else "wallet-bob"
        token = "art-01" if index % 2 == 0 else "art-02"
        version = index // 2
        yield Event(
            f"bench-{index + 1:06d}", "Listed" if version == 0 else "PriceChanged",
            token, wallet, rng.randrange(5, 25) * 10**17, version,
            1700000000 + index, f"Synthetic artwork {token}" if version == 0 else None,
        )


def percentile(sorted_samples, probability):
    position = (len(sorted_samples) - 1) * probability
    low = floor(position)
    high = min(low + 1, len(sorted_samples) - 1)
    return sorted_samples[low] + (sorted_samples[high] - sorted_samples[low]) * (position - low)


def peak_rss_bytes():
    if sys.platform not in {"linux", "darwin"}:
        return None
    import resource
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return value if sys.platform == "darwin" else value * 1024


def new_output(path):
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()):
        raise ValueError(f"Choose an empty output directory: {path}")
    for name in ("private", "public"):
        (path / name).mkdir()


def run_workflow(args):
    if args.command == "demo":
        events = [Event(**row) for row in load_jsonl(args.trace)]
        graph = ReputationGraph(**json.loads(args.graph.read_text(encoding="utf-8")))
        feedback = json.loads(args.feedback.read_text(encoding="utf-8")) if args.feedback else {}
        workload = "synthetic_example" if args.trace.resolve() == (EXAMPLES / "events.jsonl").resolve() else "user_trace"
    else:
        events = list(synthetic_events(args.events, args.seed))
        graph = ReputationGraph(**json.loads((EXAMPLES / "graph.json").read_text(encoding="utf-8")))
        feedback, workload = {}, "synthetic_benchmark"
    if not events:
        raise ValueError("Provide at least one event.")
    new_output(args.out)
    db_path = args.out / "private" / "offchain.sqlite3"
    with tempfile.TemporaryDirectory(prefix="meta-dnft-tails-") as tails, closing(Ledger(db_path, create=True)) as ledger:
        wallets = sorted({event.wallet for event in events})
        authority = CredentialAuthority(Path(tails), capacity=max(8, len(wallets) + 1))
        holders = {wallet: authority.issue(wallet) for wallet in wallets}
        market = Marketplace(ledger, authority, graph, feedback)
        timings = []
        started = time.perf_counter_ns()
        for event in events:
            event_started = time.perf_counter_ns()
            challenge = market.challenge(event)
            proof = authority.present(holders[event.wallet], challenge)
            receipt = market.submit(event, challenge.nonce, proof)
            elapsed_ms = (time.perf_counter_ns() - event_started) / 1e6
            timings.append((event.event_id, event.kind, receipt.sequence, elapsed_ms))
        seconds = (time.perf_counter_ns() - started) / 1e9
        records = ledger.audit()
        states = ledger.states()

    audit_path = args.out / "public" / "commitments.jsonl"
    with audit_path.open("w", encoding="utf-8", newline="\n") as stream:
        for record in records:
            stream.write(canonical(record) + "\n")
    with (args.out / "private" / "event_timings.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["event_id", "kind", "commitment_sequence", "latency_ms"])
        writer.writerows(timings)
    write_json(args.out / "private" / "states.json", states)
    latencies = sorted(timing[3] for timing in timings)
    metrics = {
        "workload": workload,
        "python": platform.python_version(),
        "platform": platform.system() + " " + platform.machine(),
        "submitted_events": len(events),
        "unique_commits": len(records),
        "elapsed_seconds": seconds,
        "events_per_second": len(events) / seconds,
        "latency_ms": {
            name: percentile(latencies, p) for name, p in (("p50", .50), ("p95", .95), ("p99", .99))
        },
        "peak_process_rss_bytes": peak_rss_bytes(),
        "offchain_database_bytes": db_path.stat().st_size,
        "public_commitment_jsonl_bytes": audit_path.stat().st_size,
    }
    if args.command == "benchmark":
        metrics["seed"] = args.seed
    write_json(args.out / "metrics.json", metrics)
    print(f"{len(events)} events processed, {len(records)} distinct commitments, {len(states)} tokens.")
    print(f"Outputs: {args.out}")


def audit_workflow(args):
    with closing(Ledger(args.db)) as ledger:
        records = ledger.audit()
    if args.commitments is not None and records != list(load_jsonl(args.commitments)):
        raise ValueError("Public commitments differ from the verified database log.")
    print(f"Verified {len(records)} commitments. Head: {records[-1]['commitment'] if records else GENESIS}")


def anchor_workflow(args):
    from .evm import anchor_local
    report = anchor_local(list(load_jsonl(args.commitments)))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(f"Anchored {report['count']} commitments in an in-memory EVM. Receipt file: {args.out}")


def positive_int(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("Enter a positive integer.")
    return number


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    demo = subparsers.add_parser("demo", help="Verify and apply the bundled events or a local JSONL trace.")
    demo.add_argument("--trace", type=Path, default=EXAMPLES / "events.jsonl")
    demo.add_argument("--graph", type=Path, default=EXAMPLES / "graph.json")
    demo.add_argument("--feedback", type=Path)
    demo.add_argument("--out", type=Path, default=Path("runs/demo"))
    demo.set_defaults(handler=run_workflow)
    bench = subparsers.add_parser("benchmark", help="Measure a seeded synthetic workload.")
    bench.add_argument("--events", type=positive_int, default=200)
    bench.add_argument("--seed", type=int, default=42)
    bench.add_argument("--out", type=Path, default=Path("runs/benchmark"))
    bench.set_defaults(handler=run_workflow)
    audit = subparsers.add_parser("audit", help="Recompute the off-chain log and compare an optional export.")
    audit.add_argument("--db", required=True, type=Path)
    audit.add_argument("--commitments", type=Path)
    audit.set_defaults(handler=audit_workflow)
    anchor = subparsers.add_parser("anchor-local", help="Execute commitment anchoring in a disposable local EVM.")
    anchor.add_argument("--commitments", required=True, type=Path)
    anchor.add_argument("--out", required=True, type=Path)
    anchor.set_defaults(handler=anchor_workflow)
    args = parser.parse_args()
    try:
        args.handler(args)
    except (OSError, ValueError, TypeError, KeyError, sqlite3.Error, ImportError, RuntimeError) as exc:
        parser.exit(1, f"Error: {exc}\n")


if __name__ == "__main__":
    main()
