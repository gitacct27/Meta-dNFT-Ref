"""Bounded graph signals for the two reputation events."""

from collections import defaultdict
from math import expm1, isfinite


class ReputationGraph:
    def __init__(self, edges, trusted, steps=20, restart=0.15):
        if type(steps) is not int or not 1 <= steps <= 500 or not 0 <= restart < 1:
            raise ValueError("Graph requires 1–500 steps and a restart probability in [0, 1).")
        if not isinstance(trusted, list) or not trusted or any(not isinstance(n, str) or not n for n in trusted):
            raise ValueError("Provide at least one trusted wallet alias.")
        self.trusted = frozenset(trusted)
        self.steps = steps
        self.restart = restart
        weights = defaultdict(lambda: defaultdict(float))
        nodes = set(self.trusted)
        for source, target, value in edges:
            if not isinstance(source, str) or not isinstance(target, str) or not source or not target:
                raise ValueError("Each graph edge needs two wallet aliases.")
            if type(value) not in {int, float} or not isfinite(value) or value <= 0:
                raise ValueError("Every graph edge weight must be positive and finite.")
            weights[source][target] += value
            nodes.update((source, target))
        self.transitions = {}
        for node in sorted(nodes):
            outgoing = weights.get(node, {node: 1.0})
            total = sum(outgoing.values())
            if not isfinite(total):
                raise ValueError("Total outgoing weight must be finite.")
            self.transitions[node] = tuple((dest, w / total) for dest, w in sorted(outgoing.items()))

    def hitting_time(self, wallet):
        """Expected first arrival at the trusted set, capped at the horizon."""
        if wallet not in self.transitions:
            return float(self.steps)
        times = dict.fromkeys(self.transitions, 0.0)
        for _ in range(self.steps):
            times = {
                node: 0.0 if node in self.trusted else 1 + sum(p * times[dest] for dest, p in outgoing)
                for node, outgoing in self.transitions.items()
            }
        return times[wallet]

    def walk_trust(self, wallet):
        """Probability of ending in the trusted set after a walk with restart."""
        if wallet not in self.transitions:
            return 0.0
        distribution = {wallet: 1.0}
        for _ in range(self.steps):
            next_step = defaultdict(float, {wallet: self.restart})
            for node, mass in distribution.items():
                for destination, p in self.transitions[node]:
                    next_step[destination] += mass * (1 - self.restart) * p
            distribution = next_step
        return min(1.0, sum(distribution.get(node, 0.0) for node in self.trusted))

    def update(self, kind, wallet, previous, previous_signal, elapsed, feedback):
        if kind == "Listed":
            signal = max(0.0, 1 - self.hitting_time(wallet) / self.steps)
            weight = 0.30
        else:
            signal = self.walk_trust(wallet)
            weight = 0.40
        smoothed = signal if previous_signal is None else 0.75 * previous_signal + 0.25 * signal
        decay = -0.05 * expm1(-elapsed / 86400)
        score = min(1.0, max(0.0, previous + weight * smoothed + 0.10 * feedback / 5 - decay))
        return round(score, 8), round(smoothed, 8)
