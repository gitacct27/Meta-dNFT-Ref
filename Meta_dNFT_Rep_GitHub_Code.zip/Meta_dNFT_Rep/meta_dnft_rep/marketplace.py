"""Credential-gated state transitions with a transactional commitment log."""

import json
from math import isfinite
from pathlib import Path
import secrets
import sqlite3
import time

from .model import AuditError, GENESIS, PolicyError, Receipt, canonical, digest


SCHEMA = """
CREATE TABLE IF NOT EXISTS states (
    token_id TEXT PRIMARY KEY,
    payload TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS updates (
    sequence INTEGER PRIMARY KEY,
    event_id TEXT NOT NULL UNIQUE,
    fingerprint TEXT NOT NULL,
    event_json TEXT NOT NULL,
    state_json TEXT NOT NULL,
    salt TEXT NOT NULL,
    previous TEXT NOT NULL,
    commitment TEXT NOT NULL UNIQUE
);
"""


def commitment_for(sequence, previous, event, state, salt):
    return digest({
        "domain": "meta-dnft-rep:v1", "sequence": sequence, "previous": previous,
        "event": event, "state": state, "salt": salt,
    })


class Ledger:
    def __init__(self, path: Path, *, create=False):
        if not create and not path.is_file():
            raise FileNotFoundError(f"Off-chain database does not exist: {path}")
        self.db = sqlite3.connect(path, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        if create:
            self.db.executescript(SCHEMA)

    def close(self):
        self.db.close()

    def states(self):
        return {row["token_id"]: json.loads(row["payload"])
                for row in self.db.execute("SELECT token_id, payload FROM states ORDER BY token_id")}

    def commit(self, event, graph, feedback):
        with self.db:
            self.db.execute("BEGIN IMMEDIATE")
            prior_event = self.db.execute(
                "SELECT sequence, previous, commitment, fingerprint FROM updates WHERE event_id=?",
                (event.event_id,),
            ).fetchone()
            if prior_event:
                if prior_event["fingerprint"] != event.fingerprint:
                    raise PolicyError("Event ID is already bound to different contents.")
                return Receipt(prior_event["sequence"], prior_event["previous"], prior_event["commitment"])

            row = self.db.execute("SELECT payload FROM states WHERE token_id=?", (event.token_id,)).fetchone()
            previous_state = json.loads(row["payload"]) if row else None
            if event.kind == "Listed":
                if previous_state is not None or event.expected_version != 0:
                    raise PolicyError("Listed requires an unlisted token and expected version zero.")
                name, score, previous_signal, elapsed = event.name, 0.50, None, 0
            else:
                if previous_state is None or previous_state["wallet"] != event.wallet:
                    raise PolicyError("Only the listed owner can update an existing token price.")
                if previous_state["version"] != event.expected_version:
                    raise PolicyError("Stale expected token version.")
                if previous_state["timestamp"] >= event.timestamp:
                    raise PolicyError("Event timestamp must advance for this token.")
                name, score = previous_state["name"], previous_state["reputation"]
                previous_signal = previous_state["signal_ema"]
                elapsed = event.timestamp - previous_state["timestamp"]

            score, signal_ema = graph.update(event.kind, event.wallet, score, previous_signal, elapsed, feedback)
            state = {
                "token_id": event.token_id, "wallet": event.wallet, "name": name,
                "price_wei": event.price_wei, "version": event.expected_version + 1,
                "timestamp": event.timestamp,
                "reputation": score, "signal_ema": signal_ema,
            }
            tip = self.db.execute("SELECT sequence, commitment FROM updates ORDER BY sequence DESC LIMIT 1").fetchone()
            sequence, previous = (tip["sequence"] + 1, tip["commitment"]) if tip else (1, GENESIS)
            salt = secrets.token_hex(32)
            event_json, state_json = canonical(event.payload), canonical(state)
            commitment = commitment_for(sequence, previous, event.payload, state, salt)
            self.db.execute(
                "INSERT INTO updates VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (sequence, event.event_id, event.fingerprint, event_json, state_json, salt, previous, commitment),
            )
            self.db.execute(
                "INSERT INTO states VALUES (?, ?) ON CONFLICT(token_id) DO UPDATE SET payload=excluded.payload",
                (event.token_id, state_json),
            )
            return Receipt(sequence, previous, commitment)

    def audit(self):
        expected_states, records = {}, []
        previous = GENESIS
        with self.db:
            self.db.execute("BEGIN")
            for sequence, row in enumerate(self.db.execute("SELECT * FROM updates ORDER BY sequence"), 1):
                event, state = json.loads(row["event_json"]), json.loads(row["state_json"])
                if row["sequence"] != sequence or row["previous"] != previous:
                    raise AuditError(f"Broken sequence or predecessor at row {sequence}.")
                if row["event_id"] != event["event_id"] or row["fingerprint"] != digest(event):
                    raise AuditError(f"Invalid event fingerprint at row {sequence}.")
                computed = commitment_for(sequence, previous, event, state, row["salt"])
                if row["commitment"] != computed or state["token_id"] != event["token_id"]:
                    raise AuditError(f"Commitment mismatch at row {sequence}.")
                expected_states[state["token_id"]] = state
                records.append(Receipt(sequence, previous, computed).public_record)
                previous = computed
            if self.states() != expected_states:
                raise AuditError("Materialized token states differ from the audit history.")
        return records


class Marketplace:
    def __init__(self, ledger, authority, graph, feedback=None):
        self.ledger = ledger
        self.authority = authority
        self.graph = graph
        self.feedback = {} if feedback is None else dict(feedback)
        if any(type(value) not in {int, float} or not isfinite(value) or not 0 <= value <= 5
               for value in self.feedback.values()):
            raise ValueError("Trusted feedback values must lie between 0 and 5.")
        self.challenges = {}

    def challenge(self, event):
        now = time.monotonic()
        self.challenges = {key: item for key, item in self.challenges.items() if item.expires_at >= now}
        challenge = self.authority.challenge(event)
        self.challenges[challenge.nonce] = challenge
        return challenge

    def submit(self, event, nonce, proof):
        challenge = self.challenges.pop(nonce, None)
        if challenge is None:
            raise PolicyError("Unknown or already used presentation challenge.")
        self.authority.verify(event, challenge, proof)
        return self.ledger.commit(event, self.graph, self.feedback.get(event.event_id, 0))
