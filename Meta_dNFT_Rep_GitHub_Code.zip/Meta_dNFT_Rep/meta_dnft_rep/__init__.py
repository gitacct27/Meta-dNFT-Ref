"""Meta-dNFT-Rep local reference implementation."""
