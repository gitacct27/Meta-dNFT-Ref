# Meta-dNFT-Rep

A runnable reference implementation of the event-driven reputation workflow in
*Meta-dNFT-Rep: Metaverse-assisted Dynamic NFT Reputation Scheme with
Low-Memory Off-Chain AnonCreds Service*. The repository provides a local
workflow, a synthetic benchmark, an audit command, and optional smart-contract
execution in an in-memory Ethereum virtual machine.

## Requirements

- Python 3.12 recommended. The verified environment used Python 3.12 on Linux x86-64.
- The [AnonCreds Python package](https://pypi.org/project/anoncreds/) uses a
  platform-specific native wheel. Version 0.2.3 has wheels for Linux x86-64
  and AArch64, macOS universal2, and Windows x86-64.
- The optional local EVM requires `requirements-evm.txt`. Node.js and npm are
  needed only if you want to recompile the bundled Solidity artifact.

Extract the archive and run the commands from the directory containing
`README.md`.

## Quick start

Create and activate a virtual environment:

**Windows PowerShell**

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**Linux or macOS**

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Install the pinned dependency and run the demo:

```text
python -m pip install -r requirements.txt
python -m meta_dnft_rep demo --feedback examples/feedback.json --out runs/demo
python -m meta_dnft_rep audit --db runs/demo/private/offchain.sqlite3 --commitments runs/demo/public/commitments.jsonl
python -m unittest discover -s tests -v
```

The demo processes **5 events**, creates **5 commitments**, and leaves
**2 token states**. The audit verifies the commitment chain against the
private database and exported public records. Choose an empty output
directory for a new run. The default test run skips the two EVM tests
when the optional EVM dependencies are absent.

If a configured package mirror does not carry the native wheel, install
with `python -m pip install --index-url https://pypi.org/simple -r requirements.txt`.

## Run the benchmark

```text
python -m meta_dnft_rep benchmark --events 200 --seed 42 --out runs/benchmark
```

The seed determines the prices of synthetic marketplace events.
Native credential proofs, salts, and timing observations vary across runs.
Each latency sample covers challenge creation, proof generation and
verification, and the SQLite transaction. Issuer setup, credential
issuance, export, and EVM execution occur outside the timed loop.

`metrics.json` reports p50, p95, and p99 using linear interpolation over
the observed samples, and throughput over the sequential loop. The
SQLite file size and serialized commitment size are storage measures.
Peak process RSS on Linux and macOS is reported in bytes for the entire
run, including setup. On other systems that field is `null`.

These figures describe this reference implementation and workload.
The manuscript’s Caliper, Indy, Fabric, and distributed testbed results
require their original configurations, workloads, and measurement logs.
The local benchmark makes no prediction of production gas cost, network
finality, or end-to-end transaction latency on a deployed network.

## Anchor the commitments on a local EVM

```text
python -m pip install -r requirements-evm.txt
python -m meta_dnft_rep anchor-local --commitments runs/demo/public/commitments.jsonl --out runs/demo/evm_receipts.json
python -m unittest discover -s tests -v
```

The command deploys the bundled Solidity contract on an ephemeral
Py-EVM chain, submits the five commitments from the demo, and checks
the contract’s final sequence count and head. The receipt file records
the actual local gas used, transaction hashes, and block numbers.
No external RPC, wallet key, faucet, or live token is required.

The contract restricts writes to its deployer and checks the predecessor
and commitment uniqueness. Its input consists of salted commitments;
the AnonCreds proof and token details are processed off-chain. The token
metadata in this implementation is application state in SQLite. The
Solidity contract exposes an audit anchor for this state.

To rebuild the included ABI and bytecode:

```text
cd contracts
npm ci
npm run compile
cd ..
```

The compiler is pinned to Solidity 0.8.30. The Python runner checks the
Solidity source hash against the compiled artifact.

## Supply a local trace

```text
python -m meta_dnft_rep demo --trace examples/events.jsonl --graph examples/graph.json --feedback examples/feedback.json --out runs/custom
```

Each line of the JSONL trace is one event object:

| Field | Meaning |
| --- | --- |
| `event_id` | Unique event identifier. An exact retry with a fresh proof returns the original commitment. |
| `kind` | `Listed` or `PriceChanged`. |
| `token_id`, `wallet` | Token identifier and locally enrolled wallet alias. |
| `price_wei` | Positive integer price in wei. |
| `expected_version` | Zero for a new listing, then the current state version for each update. |
| `timestamp` | Nonnegative Unix time in seconds. Updates advance time for the token. |
| `name` | Required for `Listed`; omit for `PriceChanged`. |

The graph JSON supplies directed weighted edges `[source, target, weight]`,
trusted wallet aliases, the finite walk horizon, and the restart
probability. The optional feedback file maps event IDs to curator-supplied
values in `[0, 5]`. The CLI enrolls the aliases in the input trace as
synthetic sellers for the local run. A deployment needs its own verified
enrollment and authenticated graph and feedback sources.

## Implementation and evidence

1. The local issuer creates genuine revocable AnonCreds credentials.
   For each event, the holder presents the scoped wallet alias and seller role.
   The presentation request uses a single-use nonce bound to the event digest
   and the current revocation status list. The credential’s private profile
   attribute remains undisclosed. The disclosed alias can link presentations
   at this verifier.
2. The service authorizes a new listing or an owner’s price update and
   checks the expected version. It uses a bounded first-hitting-time signal
   for listings and finite-horizon random walk with restart for price changes.
3. The reference score starts at 0.50. Hitting time is converted to proximity
   as `max(0, 1 - H / steps)`, so nearer trusted wallets contribute more.
   For a new token the smoothed signal equals the event signal, then it uses
   EMA weights 0.75 and 0.25 for previous and current signals. Event weights are
   0.30 and 0.40 for listing and price change, respectively. The update adds
   `0.10 * feedback / 5` and subtracts
   `0.05 * (1 - exp(-elapsed_seconds / 86400))` before clipping to `[0, 1]`.
   These choices operationalize the manuscript workflow for this dataset and
   do not recover the manuscript’s per-token scores.
4. The SQLite transaction stores the event, token snapshot, salt, and
   commitment together. The SHA-256 commitment covers the domain string,
   sequence, predecessor, event, state, and 32-byte random salt in canonical
   JSON. The export contains sequence, predecessor, and commitment.
   A trusted external copy or an anchored head is needed to detect a full
   rewrite by someone with control of the local database.
5. The issuer keys, holder link secrets, credentials, and proofs are created
   for the run and kept out of the output. The private database and state
   exports contain the event data and salts. Share the public commitment
   export when sharing examples of audit records.

| Location | Contents |
| --- | --- |
| `meta_dnft_rep/` | CLI, credential authority, graph scoring, SQLite marketplace and EVM adapter |
| `examples/` | Synthetic trace, graph, and feedback fixtures |
| `contracts/` | Solidity source, pinned build toolchain, ABI, and creation bytecode |
| `tests/` | Local tests of event policy, proof authorization, revocation, audit and EVM anchoring |
| `runs/<run>/private/` | Off-chain SQLite database, token state and per-event timings |
| `runs/<run>/public/commitments.jsonl` | Public audit commitment export |
| `runs/<run>/metrics.json` | Observed run summary |

## Put the project on GitHub

Create an empty repository in your GitHub account and run the following
from the extracted project directory. Replace the uppercase placeholders
with your account or organization and repository name.

```text
git init -b main
git add .
git commit -m "Add Meta-dNFT-Rep reference implementation"
git remote add origin https://github.com/OWNER/REPOSITORY.git
git push -u origin main
```

The included `.gitignore` excludes local runs, SQLite files, virtual
environments, Python caches and Node modules.
